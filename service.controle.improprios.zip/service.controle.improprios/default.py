# -*- coding: utf-8 -*-
"""Entrada do addon na lista de Add-ons de programas: abre a tela de configurações."""
import xbmcaddon

xbmcaddon.Addon('service.controle.improprios').openSettings()
