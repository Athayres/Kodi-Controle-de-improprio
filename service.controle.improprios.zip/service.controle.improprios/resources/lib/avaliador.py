# -*- coding: utf-8 -*-
"""Lógica do Controle de Impróprios, portada do Worker da Cloudflare:
classificação indicativa do Brasil (IMDb, TMDB, MDBList) + Guia dos Pais do IMDb + regras de bloqueio.
Nada do Kodi fica aqui dentro, para poder ser testado fora dele."""
import json
import os
import re
import threading
import time
import urllib.error
import urllib.parse
import urllib.request

UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) '
      'Chrome/128.0.0.0 Safari/537.36')
NIVEIS = ['Nenhum', 'Leve', 'Moderado', 'Grave']
CATEGORIAS = [
    {'key': 'sexo', 'rotulo': 'Sexo e nudez', 'ids': ['NUDITY'], 'texto': re.compile(r'nudity|sex', re.I)},
    {'key': 'violencia', 'rotulo': 'Violência e sangue', 'ids': ['VIOLENCE'], 'texto': re.compile(r'violence|gore', re.I)},
    {'key': 'palavroes', 'rotulo': 'Palavrões', 'ids': ['PROFANITY'], 'texto': re.compile(r'profanity', re.I)},
    {'key': 'drogas', 'rotulo': 'Álcool, drogas e fumo', 'ids': ['ALCOHOL'], 'texto': re.compile(r'alcohol|drugs|smoking', re.I)},
    {'key': 'susto', 'rotulo': 'Cenas intensas e assustadoras', 'ids': ['FRIGHTENING'], 'texto': re.compile(r'frightening|intense', re.I)},
]
CFG_PADRAO = {'max': {'sexo': 0, 'violencia': 1, 'palavroes': 0, 'drogas': 1, 'susto': 1}, 'idade': 18}

GUIA_TTL = 30 * 24 * 3600
NULO_TTL = 12 * 3600
MDB_NULO_TTL = 3 * 24 * 3600
FALHOU = object()  # a consulta falhou: não vale como "sem guia" e não é guardada

GRAPHQL = 'https://api.graphql.imdb.com/'
GQL_QUERY = ('query($id: ID!){ title(id:$id){ parentsGuide{ categories{ category{ id text } '
             'severity{ id text votedFor } totalSeverityVotes } } } }')
IBR_QUERY = ('query($id: ID!){ title(id:$id){ certificates(first: 250){ edges{ node{ rating country{ id } } } } } }')
CAB_GQL = {'Content-Type': 'application/json', 'Accept': 'application/json', 'User-Agent': UA,
           'Origin': 'https://www.imdb.com', 'Referer': 'https://www.imdb.com/'}
CAB_HTML = {'User-Agent': UA, 'Accept-Language': 'en-US,en;q=0.9', 'Accept': 'text/html,application/xhtml+xml'}


# ---------------------------------------------------------------- rede
def http(url, metodo='GET', cabecalhos=None, corpo=None, timeout=6):
    """Devolve (status, texto). Status 0 = falhou antes de receber resposta."""
    req = urllib.request.Request(url, data=corpo, method=metodo, headers=cabecalhos or {})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.status, r.read().decode('utf-8', 'replace')
    except urllib.error.HTTPError as e:
        try:
            txt = e.read().decode('utf-8', 'replace')
        except Exception:
            txt = ''
        return e.code, txt
    except Exception:
        return 0, ''


# ---------------------------------------------------------------- cache em arquivo
class Cache:
    def __init__(self, caminho=None):
        self.caminho = caminho
        self.dados = {}
        self.sujo = False
        if caminho and os.path.exists(caminho):
            try:
                with open(caminho, 'r', encoding='utf-8') as f:
                    d = json.load(f)
                if isinstance(d, dict):
                    self.dados = d
            except Exception:
                self.dados = {}

    def ler(self, tipo, chave):
        c = self.dados.get(tipo, {}).get(chave)
        return c if isinstance(c, dict) and 't' in c else None

    def gravar(self, tipo, chave, valor):
        self.dados.setdefault(tipo, {})[chave] = {'t': time.time(), 'v': valor}
        self.sujo = True

    def salvar(self):
        if not self.caminho or not self.sujo:
            return
        try:
            for tipo in self.dados:  # não deixa crescer sem fim
                if len(self.dados[tipo]) > 3000:
                    velhos = sorted(self.dados[tipo].items(), key=lambda kv: kv[1].get('t', 0))[:1000]
                    for k, _ in velhos:
                        del self.dados[tipo][k]
            tmp = self.caminho + '.tmp'
            with open(tmp, 'w', encoding='utf-8') as f:
                json.dump(self.dados, f, ensure_ascii=False)
            os.replace(tmp, self.caminho)
            self.sujo = False
        except Exception:
            pass


def fresco(c, ttl_ok=GUIA_TTL, ttl_nulo=NULO_TTL):
    return bool(c) and (time.time() - c['t']) < (ttl_ok if c.get('v') else ttl_nulo)


# ---------------------------------------------------------------- Guia dos Pais (IMDb)
def nivel_de(v):
    s = re.sub(r'VOTES$', '', str(v or '').upper())
    return {'NONE': 0, 'MILD': 1, 'MODERATE': 2, 'SEVERE': 3}.get(s)


def _num(v):
    try:
        return float(v)
    except (TypeError, ValueError):
        return 0.0


def _primeiro(*vals):
    for v in vals:
        if v is not None:
            return v
    return None


def nivel_do_item(el):
    s = _primeiro(el.get('severity'), el.get('severitySummary'))
    if s is not None:
        candidatos = [s.get('text'), s.get('id'), s.get('value'), s.get('label')] if isinstance(s, dict) else [s]
        for c in candidatos:
            n = nivel_de(c)
            if n is not None:
                return n
    votos = [0, 0, 0, 0]
    tem = False
    v = el.get('votes')
    if isinstance(v, dict):
        for k, i in (('noneVotes', 0), ('mildVotes', 1), ('moderateVotes', 2), ('severeVotes', 3)):
            n = _num(v.get(k))
            if n > 0:
                votos[i] += n
                tem = True
    lista = el.get('severityBreakdown') or el.get('severityVotes')
    if isinstance(lista, list):
        for it in lista:
            if not isinstance(it, dict):
                continue
            i = None
            for x in (it.get('voteType'), it.get('id'), it.get('text')):
                i = nivel_de(x)
                if i is not None:
                    break
            n = _num(_primeiro(it.get('votedFor'), it.get('votes'), it.get('count')))
            if i is not None and n > 0:
                votos[i] += n
                tem = True
    if not tem:
        return None
    total = sum(votos)
    acum = 0
    for i in range(4):
        acum += votos[i]
        if acum >= total / 2:
            return i
    return None


def _lista_de_categorias(no):
    if not isinstance(no, list):
        return False
    for e in no:
        if isinstance(e, dict) and e.get('category'):
            c = e['category']
            if isinstance(c, str) or (isinstance(c, dict) and (c.get('id') or c.get('text'))):
                return True
    return False


def coletar_categorias(no, saida=None, prof=0):
    if saida is None:
        saida = []
    if not isinstance(no, (dict, list)) or prof > 16:
        return saida
    if _lista_de_categorias(no):
        saida.append(no)
    for v in (no.values() if isinstance(no, dict) else no):
        coletar_categorias(v, saida, prof + 1)
    return saida


def guia_de_json(dados):
    guia = {}
    achou = False
    for arr in coletar_categorias(dados):
        for el in arr:
            if not isinstance(el, dict) or not el.get('category'):
                continue
            cat = el['category']
            id_ = str(cat if isinstance(cat, str) else (cat.get('id') or '')).upper()
            txt = cat if isinstance(cat, str) else str(cat.get('text') or '')
            alvo = next((x for x in CATEGORIAS if id_ in x['ids'] or x['texto'].search(txt) or x['texto'].search(id_)), None)
            if not alvo:
                continue
            nivel = nivel_do_item(el)
            if guia.get(alvo['key']) is None:
                guia[alvo['key']] = nivel
            if nivel is not None:
                achou = True
    return guia if achou else None


def guia_de_html(html):
    slugs = {'sexo': 'nudity', 'violencia': 'violence', 'palavroes': 'profanity', 'drogas': 'alcohol', 'susto': 'frightening'}
    guia = {}
    achou = False
    for key, slug in slugs.items():
        m0 = re.search('advisory-' + slug, html, re.I)
        if not m0:
            continue
        trecho = re.sub(r'<[^>]+>', ' ', html[m0.start():m0.start() + 1500])
        m = re.search(r'\b(None|Mild|Moderate|Severe)\b', trecho)
        if m:
            guia[key] = nivel_de(m.group(1))
            achou = True
    return guia if achou else None


def extrair_guia(html):
    m = re.search(r'<script id="__NEXT_DATA__"[^>]*>([\s\S]*?)</script>', html)
    if m:
        try:
            g = guia_de_json(json.loads(m.group(1)))
            if g:
                return g
        except Exception:
            pass
    return guia_de_html(html)


def consultar_imdb(imdb, fn=None):
    fn = fn or http
    corpo = json.dumps({'query': GQL_QUERY, 'variables': {'id': imdb}}).encode()
    _, txt = fn(GRAPHQL, 'POST', CAB_GQL, corpo, 6)
    j = None
    try:
        j = json.loads(txt)
    except Exception:
        pass
    if isinstance(j, dict):
        g = guia_de_json(j)
        if g:
            return g, False
        data = j.get('data')
        if isinstance(data, dict) and data.get('title') and not j.get('errors'):
            return None, False  # o IMDb respondeu e esse título não tem guia
    st, html = fn('https://www.imdb.com/title/%s/parentalguide/' % imdb, 'GET', CAB_HTML, None, 6)
    g = extrair_guia(html) if html else None
    pagina_valida = st == 200 and ('__NEXT_DATA__' in html or re.search(r'advisory-', html, re.I))
    return g, (g is None and not pagina_valida)  # página sem dados (captcha/bloqueio) = falha, não "sem guia"


def buscar_guia(imdb, cache, fn=None):
    c = cache.ler('guias', imdb)
    if fresco(c):
        return c['v']
    g, falhou = consultar_imdb(imdb, fn)
    if falhou:
        return FALHOU
    cache.gravar('guias', imdb, g)
    return g


# ---------------------------------------------------------------- TMDB
class TMDB:
    def __init__(self, chave, fn=None):
        self.chave = chave
        self.fn = fn

    def get(self, caminho, **params):
        if not self.chave:
            return None
        fn = self.fn or http
        q = {'api_key': self.chave, 'language': 'pt-BR'}
        q.update(params)
        url = 'https://api.themoviedb.org/3' + caminho + '?' + urllib.parse.urlencode(q)
        for t in range(2):
            st, txt = fn(url, 'GET', {'User-Agent': UA, 'Accept': 'application/json'}, None, 10)
            if st == 200:
                try:
                    return json.loads(txt)
                except Exception:
                    return None
            if st and st != 429 and st < 500:
                return None
            time.sleep(0.4)
        return None

    def imdb_de(self, tipo, tmdb_id):
        d = self.get('/%s/%s/external_ids' % ('tv' if tipo == 'series' else 'movie', tmdb_id))
        i = d and d.get('imdb_id')
        return i if i and re.match(r'^tt\d+$', i) else None

    def buscar(self, tipo, titulo, ano=None):
        params = {'query': titulo}
        if ano and tipo != 'series':
            params['year'] = ano
        d = self.get('/search/%s' % ('tv' if tipo == 'series' else 'movie'), **params)
        r = (d or {}).get('results') or []
        return r[0]['id'] if r else None


# ---------------------------------------------------------------- classificação indicativa do Brasil
def faixa_de_idade(n):
    if n is None or n <= 0:
        return None
    if n <= 7:
        return 'L'
    if n <= 10:
        return '10'
    if n <= 12:
        return '12'
    if n <= 14:
        return '14'
    if n <= 16:
        return '16'
    return '18'


CERT_PARA_BR = {'G': 'L', 'TV-G': 'L', 'TV-Y': 'L', 'TV-Y7': 'L', 'TV-Y7-FV': 'L', 'PG': '10', 'TV-PG': '10',
                'PG-13': '14', 'TV-14': '14', 'R': '16', 'NC-17': '18', 'TV-MA': '18', 'X': '18'}


def faixa_do_mdblist(d):
    if not isinstance(d, dict):
        return None
    f = faixa_de_idade(_num(d.get('age_rating')))
    if f:
        return f
    return CERT_PARA_BR.get(str(d.get('certification') or '').upper().strip())


def faixa_br_do_imdb(rating):
    t = str(rating or '').strip()
    if re.match(r'^(l|livre)$', t, re.I):
        return 'L'
    m = re.match(r'^(\d{1,2})\b', t)
    return m.group(1) if m and int(m.group(1)) in (10, 12, 14, 16, 18) else None


def classificacao_imdb(imdb, cache, fn=None):
    c = cache.ler('ibr', imdb)
    if fresco(c):
        return c['v']
    fn = fn or http
    corpo = json.dumps({'query': IBR_QUERY, 'variables': {'id': imdb}}).encode()
    _, txt = fn(GRAPHQL, 'POST', CAB_GQL, corpo, 6)
    try:
        j = json.loads(txt)
        edges = (((j.get('data') or {}).get('title') or {}).get('certificates') or {}).get('edges')
    except Exception:
        return None
    if not isinstance(edges, list):
        return None  # erro/bloqueio: não guarda, segue para o TMDB
    num = lambda f: 0 if f == 'L' else int(f)
    melhor = None
    for e in edges:
        n = (e or {}).get('node') or {}
        if str((n.get('country') or {}).get('id')).upper() != 'BR':
            continue
        f = faixa_br_do_imdb(n.get('rating'))
        if f is not None and (melhor is None or num(f) > num(melhor)):
            melhor = f  # mais de uma: vale a mais restrita
    cache.gravar('ibr', imdb, melhor)
    return melhor


def classificacao_tmdb(imdb, cache, tmdb):
    if not tmdb.chave:
        return None
    c = cache.ler('br', imdb)
    if fresco(c):
        return c['v']
    f = tmdb.get('/find/%s' % imdb, external_source='imdb_id')
    if f is None:
        return None
    br = None
    if f.get('movie_results'):
        d = tmdb.get('/movie/%s/release_dates' % f['movie_results'][0]['id'])
        p = next((x for x in (d or {}).get('results', []) if x.get('iso_3166_1') == 'BR'), None)
        rel = next((x for x in (p or {}).get('release_dates', []) if x.get('certification')), None)
        br = rel['certification'] if rel else None
    elif f.get('tv_results'):
        d = tmdb.get('/tv/%s/content_ratings' % f['tv_results'][0]['id'])
        p = next((x for x in (d or {}).get('results', []) if x.get('iso_3166_1') == 'BR'), None)
        br = (p or {}).get('rating') or None
    cache.gravar('br', imdb, br)
    return br


def classificacao_mdblist(imdb, tipo, cache, chave, fn=None):
    if not chave:
        return None
    c = cache.ler('mdb', imdb)
    if fresco(c, GUIA_TTL, MDB_NULO_TTL):
        return c['v']
    fn = fn or http
    t = 'show' if tipo == 'series' else 'movie'
    st, txt = fn('https://api.mdblist.com/imdb/%s/%s/?apikey=%s' % (t, imdb, urllib.parse.quote(chave)), 'GET',
                 {'User-Agent': UA}, None, 10)
    if st != 200:
        return None
    try:
        v = faixa_do_mdblist(json.loads(txt))
    except Exception:
        return None
    cache.gravar('mdb', imdb, v)
    return v


def classificacao_br(imdb, tipo, cache, tmdb, mdb_chave, fn=None):
    # ordem: 1) IMDb  2) TMDB  3) MDBList
    return (classificacao_imdb(imdb, cache, fn) or classificacao_tmdb(imdb, cache, tmdb)
            or classificacao_mdblist(imdb, tipo, cache, mdb_chave, fn))


def idade_de_br(br):
    if br is None:
        return None
    t = str(br).strip()
    if re.match(r'^(l|livre)$', t, re.I):
        return 0
    d = re.sub(r'\D', '', t)
    return int(d) if d else None


# ---------------------------------------------------------------- regras de bloqueio
def motivos_bloqueio(cfg, br, guia, bloquear_sem_info=False):
    motivos = []
    if cfg['idade'] == 18:
        return motivos  # "Sem limite" anula tudo, inclusive os limites por categoria
    liberado_por_idade = False
    if cfg['idade'] < 18:
        limite = 1 if cfg['idade'] == 0 else cfg['idade']
        idade = idade_de_br(br)
        if idade is None:
            if bloquear_sem_info:
                motivos.append('Sem classificação indicativa conhecida')
        elif idade < limite:
            liberado_por_idade = True
        else:
            alvo = 'qualquer faixa acima de Livre' if cfg['idade'] == 0 else '%d anos' % cfg['idade']
            motivos.append('Classificação %s (bloqueado a partir de %s)' % ('Livre' if idade == 0 else '%d anos' % idade, alvo))
    restrito = (not liberado_por_idade) and any(cfg['max'][c['key']] < 3 for c in CATEGORIAS)
    if restrito:
        if isinstance(guia, dict):
            for c in CATEGORIAS:
                n = guia.get(c['key'])
                if n is not None and n > cfg['max'][c['key']]:
                    motivos.append('%s: %s (limite: %s)' % (c['rotulo'], NIVEIS[n], NIVEIS[cfg['max'][c['key']]]))
        elif guia is None and bloquear_sem_info:
            motivos.append('Título sem Guia dos Pais no IMDb')
    return motivos


def avaliar(imdb, tipo, cfg, cache, tmdb, mdb_chave='', bloquear_sem_info=False, fn=None):
    """Busca guia e classificação ao mesmo tempo. Devolve (motivos, br, guia)."""
    res = {}

    def a():
        try:
            res['guia'] = buscar_guia(imdb, cache, fn)
        except Exception:
            res['guia'] = FALHOU

    def b():
        try:
            res['br'] = classificacao_br(imdb, tipo, cache, tmdb, mdb_chave, fn)
        except Exception:
            res['br'] = None

    ts = [threading.Thread(target=a), threading.Thread(target=b)]
    for t in ts:
        t.start()
    for t in ts:
        t.join(25)
    guia, br = res.get('guia', FALHOU), res.get('br')
    return motivos_bloqueio(cfg, br, guia, bloquear_sem_info), br, guia
