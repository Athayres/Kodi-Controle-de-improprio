# -*- coding: utf-8 -*-
"""Partes do Kodi usadas pelo serviço (service.py) e pelo menu de contexto (contexto.py)."""
import json
import os
import re

import xbmc
import xbmcaddon
import xbmcvfs

from resources.lib import avaliador as av

ADDON_ID = 'service.controle.improprios'
IMDB_OK = re.compile(r'^tt\d{5,}$')
IDADES_OK = (0, 10, 12, 14, 16, 18, 99)


def log(msg, nivel=xbmc.LOGINFO):
    xbmc.log('[%s] %s' % (ADDON_ID, msg), nivel)


def ler_config():
    a = xbmcaddon.Addon(ADDON_ID)  # lê de novo a cada vídeo: mudou nas configurações, vale na hora

    def inteiro(chave, padrao):
        try:
            return int(a.getSetting(chave))
        except (TypeError, ValueError):
            return padrao

    idade = inteiro('idade', 18)
    cfg = {'idade': idade if idade in IDADES_OK else 18, 'max': {}}
    for c in av.CATEGORIAS:
        v = inteiro('max_' + c['key'], av.CFG_PADRAO['max'][c['key']])
        cfg['max'][c['key']] = v if 0 <= v <= 3 else av.CFG_PADRAO['max'][c['key']]
    cfg['ativo'] = a.getSetting('ativo') != 'false'
    cfg['pausar'] = a.getSetting('pausar') != 'false'
    cfg['sem_info'] = a.getSetting('bloquear_sem_info') == 'true'
    cfg['aviso'] = a.getSetting('aviso_inicio') != 'false'
    cfg['pin'] = re.sub(r'\D', '', a.getSetting('pin') or '')
    cfg['tmdb'] = (a.getSetting('tmdb_key') or '').strip()
    cfg['mdb'] = (a.getSetting('mdblist_key') or '').strip()
    return cfg


_TAGS = re.compile(r'\[/?(?:B|I|UPPERCASE|LOWERCASE|CAPITALIZE|LIGHT|COLOR(?:\s+[^\]]*)?)\]', re.I)


def limpar(texto):
    """Tira a formatação do Kodi ([B], [/B], [COLOR red]...) que os addons colocam nos nomes."""
    t = re.sub(r'\[CR\]', ' ', str(texto or ''), flags=re.I)
    return re.sub(r'\s+', ' ', _TAGS.sub('', t)).strip()


def separar_ano(titulo):
    """"Filme X (2020)" -> ("Filme X", 2020)."""
    m = re.search(r'\s*[\(\[](\d{4})[\)\]]\s*$', titulo)
    return (titulo[:m.start()].strip(), int(m.group(1))) if m else (titulo, None)


def caminho_cache():
    perfil = xbmcvfs.translatePath('special://profile/addon_data/%s/' % ADDON_ID)
    xbmcvfs.mkdirs(perfil)
    return perfil + 'cache.json'


def rpc(metodo, params=None):
    pedido = {'jsonrpc': '2.0', 'id': 1, 'method': metodo, 'params': params or {}}
    try:
        return json.loads(xbmc.executeJSONRPC(json.dumps(pedido))).get('result') or {}
    except Exception:
        return {}


def rpc_lista(metodo):
    """Alguns métodos (Player.GetActivePlayers) devolvem uma lista em vez de um objeto."""
    try:
        r = json.loads(xbmc.executeJSONRPC(json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': metodo})))
        return r.get('result') or []
    except Exception:
        return []


def item_atual():
    for p in rpc_lista('Player.GetActivePlayers'):
        if p.get('type') == 'video':
            r = rpc('Player.GetItem', {'playerid': p['playerid'], 'properties': [
                'title', 'year', 'imdbnumber', 'uniqueid', 'tvshowid', 'showtitle', 'season', 'episode', 'file']})
            return r.get('item') or {}
    return {}


def resolver_imdb(item, tmdb):
    """Devolve (imdb, tipo). Para episódios vale o id da série. Ordem: biblioteca -> id do TMDB -> busca pelo título."""
    serie = item.get('type') in ('episode', 'tvshow', 'season') or bool(item.get('showtitle')) or int(item.get('tvshowid') or -1) > 0
    tipo = 'series' if serie else 'movie'
    uid = item.get('uniqueid') or {}
    imdb = None
    tmdb_id = None
    if serie:
        tvid = int(item.get('tvshowid') or -1)
        if tvid > 0:
            show = rpc('VideoLibrary.GetTVShowDetails', {'tvshowid': tvid, 'properties': ['imdbnumber', 'uniqueid']}).get('tvshowdetails') or {}
            su = show.get('uniqueid') or {}
            imdb = su.get('imdb') or show.get('imdbnumber')
            tmdb_id = su.get('tmdb')
    else:
        imdb = uid.get('imdb') or item.get('imdbnumber')
        tmdb_id = uid.get('tmdb')
    if imdb and IMDB_OK.match(str(imdb)):
        return str(imdb), tipo
    if tmdb_id and tmdb.chave:
        i = tmdb.imdb_de(tipo, tmdb_id)
        if i:
            return i, tipo
    if serie:  # no item de série (tvshow) o nome da série é o próprio título; num episódio, o título é do episódio
        nome = item.get('showtitle') or (item.get('title') if item.get('type') == 'tvshow' else '')
    else:
        nome = item.get('title')
    titulo, ano_do_nome = separar_ano(limpar(nome))
    ano = item.get('year') or ano_do_nome or None
    if titulo and tmdb.chave:
        tid = tmdb.buscar(tipo, titulo, ano)
        if tid:
            i = tmdb.imdb_de(tipo, tid)
            if i:
                return i, tipo
    if titulo:  # sem chave do TMDB (ou o TMDB não achou): tenta a busca pública do IMDb
        i = av.imdb_por_titulo(titulo, ano, tipo)
        if i:
            return i, tipo
    return None, tipo


def titulo_legivel(item):
    if item.get('showtitle'):
        t = limpar(item['showtitle'])
        if item.get('season') is not None and int(item.get('season', -1)) >= 0 and int(item.get('episode', -1)) >= 0:
            t += ' S%02dE%02d' % (int(item['season']), int(item['episode']))
        return t
    t, ano_do_nome = separar_ano(limpar(item.get('title') or item.get('label')) or 'Este vídeo')
    ano = item.get('year') or ano_do_nome
    return '%s (%s)' % (t, ano) if ano else t


def montar_texto(titulo, imdb, br, guia, motivos, cfg):
    """Texto do Guia de Impróprios: classificação, categorias e se o perfil libera ou bloqueia."""
    partes = [av.texto_guia(br, guia)]
    if cfg['idade'] != 18:
        if motivos:
            partes.append('[COLOR red][B]Bloqueado neste perfil:[/B][/COLOR]\n' + '\n'.join('• ' + m for m in motivos))
        else:
            partes.append('[COLOR green][B]Liberado neste perfil[/B][/COLOR]')
    texto = '\n\n'.join(p for p in partes if p)
    if not av.texto_guia(br, guia):
        texto = 'O IMDb não tem informações de classificação ou guia para este título.' if guia is not av.FALHOU else \
                'Não consegui consultar o IMDb agora. Tente de novo em alguns instantes.'
    return texto + ('\n\n[COLOR grey]IMDb: %s[/COLOR]' % imdb if imdb else '')


def guia_do_item(item, cfg):
    """Devolve (título, texto) do Guia de Impróprios de um item. Usa o cache, então o segundo pedido é rápido."""
    titulo = titulo_legivel(item)
    tmdb = av.TMDB(cfg['tmdb'])
    imdb, tipo = resolver_imdb(item, tmdb)
    if not imdb:
        return titulo, ('Não consegui identificar este título pelo nome.\n\nSe isso se repetir, coloque a chave do TMDB nas '
                        'configurações do addon: ela ajuda a achar títulos em português.')
    cache = av.Cache(caminho_cache())
    motivos, br, guia = av.avaliar(imdb, tipo, cfg, cache, tmdb, cfg['mdb'], cfg['sem_info'])
    cache.salvar()
    return titulo, montar_texto(titulo, imdb, br, guia, motivos, cfg)


def remover_atalho_antigo():
    """Versões antigas deixaram um atalho (userdata/keymaps/controle_improprios.xml) que fazia o botão Info abrir uma barra.
    Apaga esse arquivo, se existir, para o botão Info voltar a funcionar do jeito normal do Kodi."""
    try:
        caminho = xbmcvfs.translatePath('special://userdata/keymaps/') + 'controle_improprios.xml'
        if not os.path.exists(caminho):
            return
        with open(caminho, 'r', encoding='utf-8') as f:
            if ADDON_ID not in f.read():
                return  # não é o nosso arquivo: não mexe
        os.remove(caminho)
        xbmc.executebuiltin('Action(reloadkeymaps)')
        log('atalho antigo do botão Info removido')
    except Exception as e:
        log('não consegui remover o atalho antigo: %s' % e, xbmc.LOGERROR)
