# -*- coding: utf-8 -*-
"""Controle de Impróprios para o Kodi (sem servidor).
Quando um vídeo começa, confere a classificação indicativa do Brasil e o Guia dos Pais do IMDb.
Se passar do limite configurado, para o vídeo (com PIN opcional para liberar)."""
import traceback

import xbmc
import xbmcgui
import xbmcvfs

from resources.lib import avaliador as av
from resources.lib.util import (ADDON_ID, item_atual, ler_config, log, resolver_imdb, titulo_legivel)

LIBERADOS = set()  # títulos liberados com PIN nesta sessão


class Vigia(xbmc.Player):
    def __init__(self):
        xbmc.Player.__init__(self)
        self.pendente = False
        self.pausado_por_nos = False

    def onAVStarted(self):
        self.pendente = True
        try:
            if not self.isPlayingVideo():
                return
            if (xbmc.getInfoLabel('Player.Filenameandpath') or '').startswith('pvr://'):
                return  # TV ao vivo não passa pela verificação
            cfg = ler_config()
            if cfg['ativo'] and cfg['idade'] != 18 and cfg['pausar'] and not xbmc.getCondVisibility('Player.Paused'):
                self.pause()  # segura o vídeo até o veredito
                self.pausado_por_nos = True
        except Exception:
            log(traceback.format_exc(), xbmc.LOGERROR)

    def _fim(self):
        self.pendente = False
        self.pausado_por_nos = False

    def onPlayBackStopped(self):
        self._fim()

    def onPlayBackEnded(self):
        self._fim()

    def onPlayBackError(self):
        self._fim()

    def atualizar_info(self, texto):
        """Põe a classificação e as categorias no começo da sinopse que o player mostra (botão Info). Kodi 20+."""
        if not texto or not hasattr(self, 'updateInfoTag'):
            return False
        try:
            atual = self.getVideoInfoTag()
            li = xbmcgui.ListItem(atual.getTitle() or '')
            novo = li.getVideoInfoTag()
            # o Kodi troca o bloco de informações inteiro: copia o que o item já tinha
            for get, put in (('getTitle', 'setTitle'), ('getOriginalTitle', 'setOriginalTitle'), ('getYear', 'setYear'),
                             ('getMediaType', 'setMediaType'), ('getTVShowTitle', 'setTvShowTitle'),
                             ('getSeason', 'setSeason'), ('getEpisode', 'setEpisode'), ('getTagLine', 'setTagLine'),
                             ('getPlotOutline', 'setPlotOutline'), ('getMpaa', 'setMpaa'), ('getDuration', 'setDuration'),
                             ('getPremiered', 'setPremiered'), ('getDirectors', 'setDirectors'), ('getStudios', 'setStudios')):
                try:
                    valor = getattr(atual, get)()
                    if valor not in (None, '', 0, -1, []):
                        getattr(novo, put)(valor)
                except Exception:
                    pass
            plot = atual.getPlot() or ''
            novo.setPlot(texto + ('\n\n' + plot if plot else ''))
            self.updateInfoTag(li)
            return True
        except Exception:
            log(traceback.format_exc(), xbmc.LOGERROR)
            return False

    def retomar(self):
        if self.pausado_por_nos:
            self.pausado_por_nos = False
            if xbmc.getCondVisibility('Player.Paused'):
                self.pause()


def avisar_e_decidir(vigia, cfg, titulo, motivos, chave):
    """Mostra o bloqueio. Com PIN certo libera; senão para o vídeo."""
    corpo = '[B]%s[/B]\n\n%s' % (titulo, '\n'.join('• ' + m for m in motivos))
    dlg = xbmcgui.Dialog()
    if cfg['pin']:
        if dlg.yesno('Conteúdo bloqueado', corpo, nolabel='Fechar', yeslabel='Liberar com PIN'):
            for _ in range(3):
                digitado = dlg.input('PIN', type=xbmcgui.INPUT_NUMERIC, option=xbmcgui.ALPHANUM_HIDE_INPUT)
                if not digitado:
                    break
                if digitado == cfg['pin']:
                    if chave:
                        LIBERADOS.add(chave)
                    vigia.retomar()
                    return True
                dlg.notification('Controle de Impróprios', 'PIN incorreto', xbmcgui.NOTIFICATION_ERROR, 2500)
    else:
        dlg.ok('Conteúdo bloqueado', corpo)
    vigia.pausado_por_nos = False
    vigia.stop()
    return False


def mostrar_info(vigia, cfg, br, guia):
    """Aviso curto no começo do vídeo e informações na tela do botão Info do player."""
    faixa = av.rotulo_faixa(br)
    resumo = av.resumo_guia(guia)
    if not faixa and not resumo:
        return
    if cfg['aviso']:
        xbmcgui.Dialog().notification('Classificação: %s' % faixa if faixa else 'Guia dos Pais', resumo or ' ',
                                      xbmcgui.NOTIFICATION_INFO, 8000, False)
    if cfg['info_player']:
        vigia.atualizar_info(av.texto_guia(br, guia))


def verificar(vigia, cache):
    cfg = ler_config()
    bloqueia = cfg['idade'] != 18  # 18 = "Sem limite": não bloqueia, mas ainda pode mostrar as informações
    if not cfg['ativo'] or not vigia.isPlayingVideo() or not (bloqueia or cfg['aviso'] or cfg['info_player']):
        return vigia.retomar()
    item = item_atual()
    if not item or item.get('type') in ('channel', 'song', 'musicvideo'):
        return vigia.retomar()
    tmdb = av.TMDB(cfg['tmdb'])
    imdb, tipo = resolver_imdb(item, tmdb)
    titulo = titulo_legivel(item)
    if imdb and imdb in LIBERADOS:
        return vigia.retomar()
    br = guia = None
    if not imdb:
        motivos = ['Não consegui identificar o título'] if (cfg['sem_info'] and bloqueia) else []
        log('sem id do IMDb para "%s"' % titulo)
    else:
        motivos, br, guia = av.avaliar(imdb, tipo, cfg, cache, tmdb, cfg['mdb'], cfg['sem_info'])
        cache.salvar()
        log('%s %s: classificação=%s guia=%s motivos=%d' % (imdb, titulo, br, 'falhou' if guia is av.FALHOU else guia, len(motivos)))
    if motivos and bloqueia:
        if not avisar_e_decidir(vigia, cfg, titulo, motivos, imdb):
            return
    else:
        vigia.retomar()
    mostrar_info(vigia, cfg, br, guia)


def main():
    perfil = xbmcvfs.translatePath('special://profile/addon_data/%s/' % ADDON_ID)
    xbmcvfs.mkdirs(perfil)
    cache = av.Cache(perfil + 'cache.json')
    monitor = xbmc.Monitor()
    vigia = Vigia()
    log('serviço iniciado')
    while not monitor.abortRequested():
        if vigia.pendente:
            vigia.pendente = False
            try:
                verificar(vigia, cache)
            except Exception:
                log(traceback.format_exc(), xbmc.LOGERROR)
                vigia.retomar()  # se algo deu errado, não deixa o vídeo preso na pausa
        if monitor.waitForAbort(0.5):
            break


if __name__ == '__main__':
    main()
