# -*- coding: utf-8 -*-
"""Controle de Impróprios para o Kodi (sem servidor).
Quando um vídeo começa, confere a classificação indicativa do Brasil e o Guia dos Pais do IMDb.
Se passar do limite configurado, para o vídeo (com PIN opcional para liberar)."""
import json
import re
import traceback

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from resources.lib import avaliador as av

ADDON_ID = 'service.controle.improprios'
IMDB_OK = re.compile(r'^tt\d{5,}$')
IDADES_OK = (0, 10, 12, 14, 16, 18, 99)
LIBERADOS = set()  # títulos liberados com PIN nesta sessão


def log(msg, nivel=xbmc.LOGINFO):
    xbmc.log('[%s] %s' % (ADDON_ID, msg), nivel)


def ler_config():
    a = xbmcaddon.Addon(ADDON_ID)  # lê de novo a cada vídeo: mudou nas configurações, vale na hora

    def inteiro(chave, padrao):
        try:
            return int(a.getSetting(chave))
        except (TypeError, ValueError):
            return padrao

    idade = inteiro('idade', 18)
    cfg = {'idade': idade if idade in IDADES_OK else 18, 'max': {}}
    for c in av.CATEGORIAS:
        v = inteiro('max_' + c['key'], av.CFG_PADRAO['max'][c['key']])
        cfg['max'][c['key']] = v if 0 <= v <= 3 else av.CFG_PADRAO['max'][c['key']]
    cfg['ativo'] = a.getSetting('ativo') != 'false'
    cfg['pausar'] = a.getSetting('pausar') != 'false'
    cfg['sem_info'] = a.getSetting('bloquear_sem_info') == 'true'
    cfg['pin'] = re.sub(r'\D', '', a.getSetting('pin') or '')
    cfg['tmdb'] = (a.getSetting('tmdb_key') or '').strip()
    cfg['mdb'] = (a.getSetting('mdblist_key') or '').strip()
    return cfg


def rpc(metodo, params=None):
    pedido = {'jsonrpc': '2.0', 'id': 1, 'method': metodo, 'params': params or {}}
    try:
        return json.loads(xbmc.executeJSONRPC(json.dumps(pedido))).get('result') or {}
    except Exception:
        return {}


def rpc_lista(metodo):
    """Alguns métodos (Player.GetActivePlayers) devolvem uma lista em vez de um objeto."""
    try:
        r = json.loads(xbmc.executeJSONRPC(json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': metodo})))
        return r.get('result') or []
    except Exception:
        return []


def item_atual():
    for p in rpc_lista('Player.GetActivePlayers'):
        if p.get('type') == 'video':
            r = rpc('Player.GetItem', {'playerid': p['playerid'], 'properties': [
                'title', 'year', 'imdbnumber', 'uniqueid', 'tvshowid', 'showtitle', 'season', 'episode', 'file']})
            return r.get('item') or {}
    return {}


def resolver_imdb(item, tmdb):
    """Devolve (imdb, tipo). Para episódios vale o id da série. Ordem: biblioteca -> id do TMDB -> busca pelo título."""
    serie = item.get('type') == 'episode' or bool(item.get('showtitle')) or int(item.get('tvshowid') or -1) > 0
    tipo = 'series' if serie else 'movie'
    uid = item.get('uniqueid') or {}
    imdb = None
    tmdb_id = None
    if serie:
        tvid = int(item.get('tvshowid') or -1)
        if tvid > 0:
            show = rpc('VideoLibrary.GetTVShowDetails', {'tvshowid': tvid, 'properties': ['imdbnumber', 'uniqueid']}).get('tvshowdetails') or {}
            su = show.get('uniqueid') or {}
            imdb = su.get('imdb') or show.get('imdbnumber')
            tmdb_id = su.get('tmdb')
    else:
        imdb = uid.get('imdb') or item.get('imdbnumber')
        tmdb_id = uid.get('tmdb')
    if imdb and IMDB_OK.match(str(imdb)):
        return str(imdb), tipo
    if tmdb_id and tmdb.chave:
        i = tmdb.imdb_de(tipo, tmdb_id)
        if i:
            return i, tipo
    titulo = item.get('showtitle') if serie else item.get('title')
    if titulo and tmdb.chave:
        tid = tmdb.buscar(tipo, titulo, item.get('year') or None)
        if tid:
            i = tmdb.imdb_de(tipo, tid)
            if i:
                return i, tipo
    return None, tipo


def titulo_legivel(item):
    if item.get('showtitle'):
        t = item['showtitle']
        if item.get('season') is not None and int(item.get('season', -1)) >= 0 and int(item.get('episode', -1)) >= 0:
            t += ' S%02dE%02d' % (int(item['season']), int(item['episode']))
        return t
    t = item.get('title') or item.get('label') or 'Este vídeo'
    return '%s (%s)' % (t, item['year']) if item.get('year') else t


class Vigia(xbmc.Player):
    def __init__(self):
        xbmc.Player.__init__(self)
        self.pendente = False
        self.pausado_por_nos = False

    def onAVStarted(self):
        self.pendente = True
        try:
            if not self.isPlayingVideo():
                return
            if (xbmc.getInfoLabel('Player.Filenameandpath') or '').startswith('pvr://'):
                return  # TV ao vivo não passa pela verificação
            cfg = ler_config()
            if cfg['ativo'] and cfg['idade'] != 18 and cfg['pausar'] and not xbmc.getCondVisibility('Player.Paused'):
                self.pause()  # segura o vídeo até o veredito
                self.pausado_por_nos = True
        except Exception:
            log(traceback.format_exc(), xbmc.LOGERROR)

    def _fim(self):
        self.pendente = False
        self.pausado_por_nos = False

    def onPlayBackStopped(self):
        self._fim()

    def onPlayBackEnded(self):
        self._fim()

    def onPlayBackError(self):
        self._fim()

    def retomar(self):
        if self.pausado_por_nos:
            self.pausado_por_nos = False
            if xbmc.getCondVisibility('Player.Paused'):
                self.pause()


def avisar_e_decidir(vigia, cfg, titulo, motivos, chave):
    """Mostra o bloqueio. Com PIN certo libera; senão para o vídeo."""
    corpo = '[B]%s[/B]\n\n%s' % (titulo, '\n'.join('• ' + m for m in motivos))
    dlg = xbmcgui.Dialog()
    if cfg['pin']:
        if dlg.yesno('Conteúdo bloqueado', corpo, nolabel='Fechar', yeslabel='Liberar com PIN'):
            for _ in range(3):
                digitado = dlg.input('PIN', type=xbmcgui.INPUT_NUMERIC, option=xbmcgui.ALPHANUM_HIDE_INPUT)
                if not digitado:
                    break
                if digitado == cfg['pin']:
                    if chave:
                        LIBERADOS.add(chave)
                    vigia.retomar()
                    return
                dlg.notification('Controle de Impróprios', 'PIN incorreto', xbmcgui.NOTIFICATION_ERROR, 2500)
    else:
        dlg.ok('Conteúdo bloqueado', corpo)
    vigia.pausado_por_nos = False
    vigia.stop()


def verificar(vigia, cache):
    cfg = ler_config()
    if not cfg['ativo'] or cfg['idade'] == 18 or not vigia.isPlayingVideo():
        return vigia.retomar()
    item = item_atual()
    if not item or item.get('type') in ('channel', 'song', 'musicvideo'):
        return vigia.retomar()
    tmdb = av.TMDB(cfg['tmdb'])
    imdb, tipo = resolver_imdb(item, tmdb)
    titulo = titulo_legivel(item)
    if imdb and imdb in LIBERADOS:
        return vigia.retomar()
    if not imdb:
        motivos = ['Não consegui identificar o título'] if cfg['sem_info'] else []
        log('sem id do IMDb para "%s"' % titulo)
    else:
        motivos, br, guia = av.avaliar(imdb, tipo, cfg, cache, tmdb, cfg['mdb'], cfg['sem_info'])
        cache.salvar()
        log('%s %s: classificação=%s guia=%s motivos=%d' % (imdb, titulo, br, 'falhou' if guia is av.FALHOU else guia, len(motivos)))
    if not motivos:
        return vigia.retomar()
    avisar_e_decidir(vigia, cfg, titulo, motivos, imdb)


def main():
    perfil = xbmcvfs.translatePath('special://profile/addon_data/%s/' % ADDON_ID)
    xbmcvfs.mkdirs(perfil)
    cache = av.Cache(perfil + 'cache.json')
    monitor = xbmc.Monitor()
    vigia = Vigia()
    log('serviço iniciado')
    while not monitor.abortRequested():
        if vigia.pendente:
            vigia.pendente = False
            try:
                verificar(vigia, cache)
            except Exception:
                log(traceback.format_exc(), xbmc.LOGERROR)
                vigia.retomar()  # se algo deu errado, não deixa o vídeo preso na pausa
        if monitor.waitForAbort(0.5):
            break


if __name__ == '__main__':
    main()
