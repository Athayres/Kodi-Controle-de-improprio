# -*- coding: utf-8 -*-
"""Menu de contexto "Guia dos Pais": mostra a classificação e o nível de cada categoria do item selecionado,
antes de dar play. Também diz se o título seria liberado ou bloqueado com os limites deste perfil."""
import sys

import xbmc
import xbmcgui
import xbmcvfs

from resources.lib import avaliador as av
from resources.lib.util import ADDON_ID, limpar, ler_config, resolver_imdb, rpc, titulo_legivel


def item_do_listitem(li):
    """Monta o mesmo formato de item que o serviço usa, a partir do item selecionado na lista."""
    tag = li.getVideoInfoTag()

    def pegar(nome, padrao=''):
        try:
            v = getattr(tag, nome)()
            return v if v not in (None,) else padrao
        except Exception:
            return padrao

    tipo = pegar('getMediaType')
    item = {'type': tipo, 'title': limpar(pegar('getTitle') or li.getLabel()), 'year': pegar('getYear', 0),
            'imdbnumber': pegar('getIMDBNumber'), 'showtitle': limpar(pegar('getTVShowTitle')),
            'season': pegar('getSeason', -1), 'episode': pegar('getEpisode', -1), 'uniqueid': {}}
    for k in ('imdb', 'tmdb'):
        try:
            v = tag.getUniqueID(k)
            if v:
                item['uniqueid'][k] = v
        except Exception:
            pass
    try:
        dbid = int(pegar('getDbId', -1) or -1)
    except (TypeError, ValueError):
        dbid = -1
    if dbid > 0:  # item da biblioteca: descobre a série para episódios e temporadas
        if tipo == 'tvshow':
            item['tvshowid'] = dbid
            item['showtitle'] = item['showtitle'] or item['title']
        elif tipo == 'episode':
            r = rpc('VideoLibrary.GetEpisodeDetails', {'episodeid': dbid, 'properties': ['tvshowid']}).get('episodedetails') or {}
            item['tvshowid'] = r.get('tvshowid', -1)
        elif tipo == 'season':
            r = rpc('VideoLibrary.GetSeasonDetails', {'seasonid': dbid, 'properties': ['tvshowid']}).get('seasondetails') or {}
            item['tvshowid'] = r.get('tvshowid', -1)
    return item


def montar_texto(titulo, imdb, br, guia, motivos, cfg):
    partes = [av.texto_guia(br, guia)]
    if cfg['idade'] != 18:
        if motivos:
            partes.append('[COLOR red][B]Bloqueado neste perfil:[/B][/COLOR]\n' + '\n'.join('• ' + m for m in motivos))
        else:
            partes.append('[COLOR green][B]Liberado neste perfil[/B][/COLOR]')
    texto = '\n\n'.join(p for p in partes if p)
    if not av.texto_guia(br, guia):
        texto = 'O IMDb não tem informações de classificação ou guia para este título.' if guia is not av.FALHOU else \
                'Não consegui consultar o IMDb agora. Tente de novo em alguns instantes.'
    return texto + ('\n\n[COLOR grey]IMDb: %s[/COLOR]' % imdb if imdb else '')


def main(li=None):
    li = li or getattr(sys, 'listitem', None)
    dlg = xbmcgui.Dialog()
    if li is None:
        return dlg.ok('Guia dos Pais', 'Não consegui ler o item selecionado.')
    item = item_do_listitem(li)
    titulo = titulo_legivel(item)
    cfg = ler_config()
    tmdb = av.TMDB(cfg['tmdb'])
    xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
    try:
        imdb, tipo = resolver_imdb(item, tmdb)
        if not imdb:
            texto = ('Não consegui identificar este título pelo nome.\n\nSe isso se repetir, coloque a chave do TMDB nas '
                     'configurações do addon: ela ajuda a achar títulos em português.')
        else:
            perfil = xbmcvfs.translatePath('special://profile/addon_data/%s/' % ADDON_ID)
            xbmcvfs.mkdirs(perfil)
            cache = av.Cache(perfil + 'cache.json')
            motivos, br, guia = av.avaliar(imdb, tipo, cfg, cache, tmdb, cfg['mdb'], cfg['sem_info'])
            cache.salvar()
            texto = montar_texto(titulo, imdb, br, guia, motivos, cfg)
    finally:
        xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
    dlg.textviewer('Guia dos Pais — %s' % titulo, texto)


if __name__ == '__main__':
    main()
