# -*- coding: utf-8 -*-
"""Partes do Kodi usadas pelo serviço (service.py) e pelo menu de contexto (contexto.py)."""
import json
import os
import re
from urllib.parse import unquote

import xbmc
import xbmcaddon
import xbmcvfs

from resources.lib import avaliador as av

ADDON_ID = 'service.controle.improprios'
IMDB_OK = re.compile(r'^tt\d{5,}$')
IDADES_OK = (0, 10, 12, 14, 16, 18, 99)


def log(msg, nivel=xbmc.LOGINFO):
    xbmc.log('[%s] %s' % (ADDON_ID, msg), nivel)


def ler_config():
    a = xbmcaddon.Addon(ADDON_ID)  # lê de novo a cada vídeo: mudou nas configurações, vale na hora

    def inteiro(chave, padrao):
        try:
            return int(a.getSetting(chave))
        except (TypeError, ValueError):
            return padrao

    idade = inteiro('idade', 18)
    cfg = {'idade': idade if idade in IDADES_OK else 18, 'max': {}}
    for c in av.CATEGORIAS:
        v = inteiro('max_' + c['key'], av.CFG_PADRAO['max'][c['key']])
        cfg['max'][c['key']] = v if 0 <= v <= 3 else av.CFG_PADRAO['max'][c['key']]
    cfg['ativo'] = a.getSetting('ativo') != 'false'
    cfg['pausar'] = a.getSetting('pausar') != 'false'
    cfg['sem_info'] = a.getSetting('bloquear_sem_info') == 'true'
    cfg['aviso'] = a.getSetting('aviso_inicio') != 'false'
    cfg['painel'] = a.getSetting('painel_info') != 'false'
    cfg['pin'] = re.sub(r'\D', '', a.getSetting('pin') or '')
    cfg['tmdb'] = (a.getSetting('tmdb_key') or '').strip()
    cfg['mdb'] = (a.getSetting('mdblist_key') or '').strip()
    return cfg


_TAGS = re.compile(r'\[/?(?:B|I|UPPERCASE|LOWERCASE|CAPITALIZE|LIGHT|COLOR(?:\s+[^\]]*)?)\]', re.I)


def limpar(texto):
    """Tira a formatação do Kodi ([B], [/B], [COLOR red]...) que os addons colocam nos nomes."""
    t = re.sub(r'\[CR\]', ' ', str(texto or ''), flags=re.I)
    return re.sub(r'\s+', ' ', _TAGS.sub('', t)).strip()


def separar_ano(titulo):
    """"Filme X (2020)" -> ("Filme X", 2020)."""
    m = re.search(r'\s*[\(\[](\d{4})[\)\]]\s*$', titulo)
    return (titulo[:m.start()].strip(), int(m.group(1))) if m else (titulo, None)


# palavras de release (qualidade, codec, fonte, idioma) que não fazem parte do título
_LIXO = re.compile(r'^(?:\d{3,4}p|4k|uhd|hdr\d*|bluray|blu-?ray|bdrip|brrip|bdremux|remux|web-?dl|web-?rip|hdtv|hdrip|dvdrip|dvdscr|'
                   r'hdcam|x26[45]|h26[45]|hevc|avc|xvid|divx|10bit|aac\d*|ac3|eac3|dd\d*|ddp\d*|dts|dtshd|truehd|atmos|flac|'
                   r'dual|dublado|dublada|legendado|legendada|nacional|multi|audio|áudio|ptbr|pt-?br|rip|torrent|yts|rarbg|bludv|'
                   r'lapumia|hd|fhd)$', re.I)
_ANO = re.compile(r'^(?:19|20)\d{2}$')
_SITE = re.compile(r'^\s*(?:www\.)?[\w-]+\.(?:com|net|org|to|cc|tv|info|biz)\b[\s._-]*', re.I)


def nome_de_release(texto, de_arquivo=False):
    """'Filme.Legal.2019.1080p.BluRay.x264.DUAL' -> ('Filme Legal', 2019).
    Título que já está limpo ('Toy Story 3', 'S.W.A.T.') volta igual, sem ano. de_arquivo=True: o texto é nome de arquivo
    (pontos e sublinhados viram espaços mesmo sem palavra de release)."""
    base = re.sub(r'\.(?:mkv|mp4|avi|m4v|mov|webm|ts|wmv|flv)$', '', str(texto or '').strip(), flags=re.I)
    base = _SITE.sub('', re.sub(r'\[[^\]]*\]', ' ', base))
    cand = base
    if de_arquivo or re.search(r'[._]', cand):
        cand = re.sub(r'(?i)\bh\.(26[45])\b', r'x\1', cand)
        cand = re.sub(r'(?<!\d)(?:[57]\.1|2\.0)(?!\d)', ' ', cand)  # canais de áudio (5.1, 7.1, 2.0)
        cand = re.sub(r'[._]+', ' ', cand)
    toks = cand.split()
    corte = next((i for i, w in enumerate(toks) if i >= 1 and _LIXO.match(w)), None)
    if corte is not None:
        toks = toks[:corte]
    nome_de_arquivo = de_arquivo or bool(re.search(r'[._]', base))
    if not toks or (corte is None and not de_arquivo and not (nome_de_arquivo and any(_ANO.match(w) for w in toks[1:]))):
        return base.strip() or str(texto or '').strip(), None  # nada de release reconhecido: não mexe
    ano = None
    if len(toks) >= 2 and _ANO.match(toks[-1]):
        ano = int(toks.pop())
    return ' '.join(toks), ano


def nome_do_arquivo(item):
    """Nome do arquivo de vídeo que o Kodi está tocando ('' se for um endereço de addon sem nome de arquivo)."""
    f = str(item.get('file') or '')
    if not f or f.startswith('pvr://'):
        return ''
    nome = unquote(f.split('?')[0].replace('\\', '/').rstrip('/').split('/')[-1])
    return nome if re.search(r'\.(?:mkv|mp4|avi|m4v|mov|webm|ts|wmv|flv)$', nome, re.I) else ''


def candidatos_de_titulo(item, serie):
    """Títulos para procurar: 1º o que o Kodi informou; 2º o nome do arquivo. Cada um vem limpo, com (título, ano, ano_tirado_do_nome)."""
    arq = nome_do_arquivo(item)
    brutos = []  # (texto, veio_do_nome_do_arquivo)
    titulo_do_item = item.get('title') or item.get('label')  # o 'title' do JSON-RPC vem vazio em muitos addons: o nome fica no 'label'
    if serie:
        brutos.append((item.get('showtitle') or (titulo_do_item if item.get('type') == 'tvshow' else ''), False))
        for texto, do_arq in ((titulo_do_item, False), (arq, True)):  # "Nome S01E02 ..." -> "Nome"
            m = re.match(r'^(.*?)[ ._-]+(?:S\d{1,2}[ ._-]?E\d{1,3}|\d{1,2}x\d{2,3})(?![\dp])', str(texto or ''), re.I)
            if m:
                brutos.append((m.group(1), do_arq))
    else:
        brutos.append((titulo_do_item, False))
        brutos.append((item.get('originaltitle'), False))
        if arq:
            brutos.append((arq, True))
    saida, vistos = [], set()
    for nome, do_arquivo in brutos:
        titulo, ano_do_nome = separar_ano(limpar(nome))
        titulo, ano_release = nome_de_release(titulo, do_arquivo)
        if not titulo:
            continue
        ano = item.get('year') or ano_do_nome or ano_release or None
        if (titulo.lower(), ano) in vistos:
            continue
        vistos.add((titulo.lower(), ano))
        saida.append((titulo, ano, None if (item.get('year') or ano_do_nome) else ano_release))
    return saida


def caminho_cache():
    perfil = xbmcvfs.translatePath('special://profile/addon_data/%s/' % ADDON_ID)
    xbmcvfs.mkdirs(perfil)
    return perfil + 'cache.json'


def rpc(metodo, params=None):
    pedido = {'jsonrpc': '2.0', 'id': 1, 'method': metodo, 'params': params or {}}
    try:
        return json.loads(xbmc.executeJSONRPC(json.dumps(pedido))).get('result') or {}
    except Exception:
        return {}


def rpc_lista(metodo):
    """Alguns métodos (Player.GetActivePlayers) devolvem uma lista em vez de um objeto."""
    try:
        r = json.loads(xbmc.executeJSONRPC(json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': metodo})))
        return r.get('result') or []
    except Exception:
        return []


def _inteiro(v, padrao=-1):
    try:
        return int(v)
    except (TypeError, ValueError):
        return padrao


def completar_item(item):
    """Addons de vídeo costumam deixar o 'title' do JSON-RPC vazio (o nome fica só no 'label') e os ids só na tag do vídeo.
    Completa o que faltou com a tag do player e os InfoLabels, do mesmo jeito que o menu de contexto lê o item da lista."""
    def info(rotulo):
        v = xbmc.getInfoLabel(rotulo)
        return v if v and v != rotulo else ''

    try:
        tag = xbmc.Player().getVideoInfoTag()
    except Exception:
        tag = None

    def da_tag(nome, *args):
        try:
            v = getattr(tag, nome)(*args)
            return v if v is not None else ''
        except Exception:
            return ''

    uid = dict(item.get('uniqueid') or {})
    for k in ('imdb', 'tmdb'):
        if not uid.get(k):
            v = da_tag('getUniqueID', k)
            if v:
                uid[k] = v
    item['uniqueid'] = uid
    if not (item.get('imdbnumber') or uid.get('imdb')):
        item['imdbnumber'] = da_tag('getIMDBNumber') or info('VideoPlayer.IMDBNumber')
    if not item.get('title'):
        item['title'] = limpar(da_tag('getTitle') or info('VideoPlayer.Title') or item.get('label') or info('Player.Title'))
    item['originaltitle'] = limpar(item.get('originaltitle') or da_tag('getOriginalTitle') or info('VideoPlayer.OriginalTitle'))
    if not item.get('showtitle'):
        item['showtitle'] = limpar(da_tag('getTVShowTitle') or info('VideoPlayer.TVShowTitle'))
    if not item.get('year') or _inteiro(item.get('year'), 0) <= 0:
        item['year'] = _inteiro(da_tag('getYear') or info('VideoPlayer.Year'), 0)
    for chave, getter, rotulo in (('season', 'getSeason', 'VideoPlayer.Season'), ('episode', 'getEpisode', 'VideoPlayer.Episode')):
        if _inteiro(item.get(chave), -1) < 0:
            v = _inteiro(da_tag(getter) or info(rotulo), -1)
            if v >= 0:
                item[chave] = v
    if item.get('type') in (None, '', 'unknown'):
        tipo = da_tag('getMediaType')
        if tipo:
            item['type'] = tipo
    if not item.get('file'):
        item['file'] = info('Player.Filenameandpath')
    return item


def origem_do_item(item):
    """De onde veio o vídeo: 'plugin.video.xyz' (addon), 'http', 'smb'..., sem o resto do endereço (que pode ter senha/token)."""
    f = str(item.get('file') or '')
    m = re.match(r'^plugin://([^/?]+)', f)
    if m:
        return m.group(1)
    m = re.match(r'^([a-z][a-z0-9+.-]*)://', f, re.I)
    return m.group(1).lower() if m else ('arquivo local' if f else '')


def descrever_item(item):
    uid = item.get('uniqueid') or {}
    return 'tipo=%s título=%r label=%r série=%r original=%r ano=%s imdb=%s tmdb=%s S%sE%s origem=%s arquivo=%r' % (
        item.get('type') or '?', item.get('title') or '', item.get('label') or '', item.get('showtitle') or '',
        item.get('originaltitle') or '', item.get('year') or '?', uid.get('imdb') or item.get('imdbnumber') or '—',
        uid.get('tmdb') or '—', item.get('season', '?'), item.get('episode', '?'), origem_do_item(item) or '?', nome_do_arquivo(item))


def item_atual():
    for p in rpc_lista('Player.GetActivePlayers'):
        if p.get('type') == 'video':
            r = rpc('Player.GetItem', {'playerid': p['playerid'], 'properties': [
                'title', 'year', 'imdbnumber', 'uniqueid', 'tvshowid', 'showtitle', 'season', 'episode', 'file', 'originaltitle']})
            item = completar_item(r.get('item') or {})
            log('item do player: %s' % descrever_item(item))
            return item
    return {}


_EPISODIO = re.compile(r'(?:^|[ ._-])(?:S\d{1,2}[ ._-]?E\d{1,3}|\d{1,2}x\d{2,3})(?![\dp])', re.I)


def resolver_imdb(item, tmdb):
    """Devolve (imdb, tipo). Para episódios vale o id da série. Ordem: biblioteca -> id do TMDB -> busca pelo título."""
    serie = item.get('type') in ('episode', 'tvshow', 'season') or bool(item.get('showtitle')) or int(item.get('tvshowid') or -1) > 0
    if not serie and item.get('type') != 'movie':  # tipo desconhecido: "Nome S01E02" no título/arquivo indica episódio
        serie = bool(_EPISODIO.search(' '.join([str(item.get('title') or ''), str(item.get('label') or ''), nome_do_arquivo(item)])))
    tipo = 'series' if serie else 'movie'
    uid = item.get('uniqueid') or {}
    imdb = None
    tmdb_id = None
    if serie:
        tvid = int(item.get('tvshowid') or -1)
        if tvid > 0:
            show = rpc('VideoLibrary.GetTVShowDetails', {'tvshowid': tvid, 'properties': ['imdbnumber', 'uniqueid']}).get('tvshowdetails') or {}
            su = show.get('uniqueid') or {}
            imdb = su.get('imdb') or show.get('imdbnumber')
            tmdb_id = su.get('tmdb')
    else:
        imdb = uid.get('imdb') or item.get('imdbnumber')
        tmdb_id = uid.get('tmdb')
    if imdb and IMDB_OK.match(str(imdb)):
        return str(imdb), tipo
    if tmdb_id and tmdb.chave:
        i = tmdb.imdb_de(tipo, tmdb_id)
        if i:
            return i, tipo
    if not serie:  # addons de vídeo costumam embutir o id do IMDb no endereço do vídeo (ex.: ...?imdb=tt0111161)
        m = re.search(r'(?<![A-Za-z0-9])(tt\d{7,9})(?!\d)', str(item.get('file') or ''))
        if m:
            return m.group(1), tipo
    # no item de série (tvshow) o nome da série é o próprio título; num episódio, o título é do episódio
    candidatos = candidatos_de_titulo(item, serie)
    for titulo, ano, ano_da_release in candidatos:
        # se o "ano" saiu do nome e o título tem número de ano (Blade Runner 2049), tenta também com ele dentro do título
        consultas = [(titulo, ano)] + ([('%s %s' % (titulo, ano_da_release), None)] if ano_da_release else [])
        if tmdb.chave:
            for consulta, a in consultas:
                tid = tmdb.buscar(tipo, consulta, a)
                i = tid and tmdb.imdb_de(tipo, tid)
                if i:
                    return i, tipo
        for consulta, a in consultas:  # sem chave do TMDB (ou o TMDB não achou): tenta a busca pública do IMDb
            i = av.imdb_por_titulo(consulta, a, tipo)
            if i:
                return i, tipo
    log('não achei o IMDb; procurei por: %s' % (' | '.join('%s (%s)' % (t, a or '?') for t, a, _ in candidatos) or '(nenhum nome)'))
    return None, tipo


def titulo_legivel(item):
    if item.get('showtitle'):
        t = limpar(item['showtitle'])
        if item.get('season') is not None and int(item.get('season', -1)) >= 0 and int(item.get('episode', -1)) >= 0:
            t += ' S%02dE%02d' % (int(item['season']), int(item['episode']))
        return t
    t, ano_do_nome = separar_ano(limpar(item.get('title') or item.get('label')) or 'Este vídeo')
    ano = item.get('year') or ano_do_nome
    return '%s (%s)' % (t, ano) if ano else t


def montar_texto(titulo, imdb, br, guia, motivos, cfg):
    """Texto do Guia de Impróprios: classificação, categorias e se o perfil libera ou bloqueia."""
    partes = [av.texto_guia(br, guia)]
    if cfg['idade'] != 18:
        if motivos:
            partes.append('[COLOR red][B]Bloqueado neste perfil:[/B][/COLOR]\n' + '\n'.join('• ' + m for m in motivos))
        else:
            partes.append('[COLOR green][B]Liberado neste perfil[/B][/COLOR]')
    texto = '\n\n'.join(p for p in partes if p)
    if not av.texto_guia(br, guia):
        texto = 'O IMDb não tem informações de classificação ou guia para este título.' if guia is not av.FALHOU else \
                'Não consegui consultar o IMDb agora. Tente de novo em alguns instantes.'
    return texto + ('\n\n[COLOR grey]IMDb: %s[/COLOR]' % imdb if imdb else '')


def o_que_o_kodi_informou(item):
    """Resumo do que o Kodi disse sobre o vídeo (título, tipo e ids), para mostrar quando não dá para identificar."""
    uid = item.get('uniqueid') or {}
    arq = nome_do_arquivo(item)
    origem = origem_do_item(item)
    return '%s · tipo %s · IMDb %s · TMDB %s%s%s' % (titulo_legivel(item), item.get('type') or '?',
                                                      uid.get('imdb') or item.get('imdbnumber') or '—', uid.get('tmdb') or '—',
                                                      (' · origem %s' % origem) if origem else '',
                                                      (' · arquivo %s' % arq[:70]) if arq else '')


def dados_do_item(item, cfg):
    """Classificação e guia de um item (usa o cache, então o segundo pedido é rápido).
    Sempre devolve um dicionário; se o título não foi identificado, 'imdb' vem vazio e 'lido' diz o que o Kodi informou."""
    tmdb = av.TMDB(cfg['tmdb'])
    imdb, tipo = resolver_imdb(item, tmdb)
    if not imdb:
        return {'titulo': titulo_legivel(item), 'imdb': None, 'br': None, 'guia': None, 'motivos': [], 'lido': o_que_o_kodi_informou(item)}
    cache = av.Cache(caminho_cache())
    motivos, br, guia = av.avaliar(imdb, tipo, cfg, cache, tmdb, cfg['mdb'], cfg['sem_info'])
    cache.salvar()
    return {'titulo': titulo_legivel(item), 'imdb': imdb, 'br': br, 'guia': guia, 'motivos': motivos}


def guia_do_item(item, cfg):
    """Devolve (título, texto) do Guia de Impróprios de um item. Usa o cache, então o segundo pedido é rápido."""
    titulo = titulo_legivel(item)
    d = dados_do_item(item, cfg)
    if not d['imdb']:
        return titulo, ('Não consegui identificar este título pelo nome.\n\nSe isso se repetir, coloque a chave do TMDB nas '
                        'configurações do addon: ela ajuda a achar títulos em português.')
    return titulo, montar_texto(titulo, d['imdb'], d['br'], d['guia'], d['motivos'], cfg)


def remover_atalho_antigo():
    """Versões antigas deixaram um atalho (userdata/keymaps/controle_improprios.xml) que fazia o botão Info abrir uma barra.
    Apaga esse arquivo, se existir, para o botão Info voltar a funcionar do jeito normal do Kodi."""
    try:
        caminho = xbmcvfs.translatePath('special://userdata/keymaps/') + 'controle_improprios.xml'
        if not os.path.exists(caminho):
            return
        with open(caminho, 'r', encoding='utf-8') as f:
            if ADDON_ID not in f.read():
                return  # não é o nosso arquivo: não mexe
        os.remove(caminho)
        xbmc.executebuiltin('Action(reloadkeymaps)')
        log('atalho antigo do botão Info removido')
    except Exception as e:
        log('não consegui remover o atalho antigo: %s' % e, xbmc.LOGERROR)
