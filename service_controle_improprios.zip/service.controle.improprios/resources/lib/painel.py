# -*- coding: utf-8 -*-
"""Painel do guia de impróprios, desenhado DENTRO da tela de resumo (sinopse) do Kodi, a que o botão Info abre.
Como os controles ficam dentro dessa janela, o painel não captura nenhum botão e some junto com ela."""
import os

import xbmcaddon
import xbmcgui

from resources.lib import avaliador as av

JANELA_RESUMO = 10142  # fullscreeninfo: a tela de resumo que o botão Info abre durante o vídeo
ALINHA_CENTRO = 6      # centro na horizontal (2) + centro na vertical (4)

COR_FAIXA = {'L': '0xFF2EAD5B', '10': '0xFF1F78C8', '12': '0xFFF2C94C', '14': '0xFFF2994A', '16': '0xFFE0402F', '18': '0xFF000000'}
TEXTO_FAIXA = {'L': 'Livre para todos os públicos', '10': 'Não recomendado para menores de 10 anos',
               '12': 'Não recomendado para menores de 12 anos', '14': 'Não recomendado para menores de 14 anos',
               '16': 'Não recomendado para menores de 16 anos', '18': 'Não recomendado para menores de 18 anos'}
# Barra de 3 segmentos que vai acendendo conforme o nível sobe, com o nome do nível ao lado:
#   Nenhum = barra branca (transparente) | Leve = 1 verde | Moderado = 2 (até o amarelo) | Grave = 3 (até o vermelho)
COR_SEGMENTO = ['0xFF2EAD5B', '0xFFF2C94C', '0xFFEB5757']  # verde, amarelo, vermelho
COR_NENHUM = '0x99FFFFFF'


def cor_do_nivel(nivel):
    """Cor do nome do nível: Nenhum branco; Leve verde; Moderado amarelo; Grave vermelho; sem informação cinza."""
    if nivel is None:
        return COR_CINZA
    return '0xFFFFFFFF' if nivel == 0 else COR_SEGMENTO[nivel - 1]


COR_FUNDO, COR_VAZIO, COR_TEXTO, COR_CINZA = '0xF012161B', '0xFF2B3138', '0xFFD0D4D9', '0xFF7C838B'


def faixa_normalizada(br):
    """'12', 'L', 'Livre', 14 -> chave de COR_FAIXA (ou None)."""
    i = av.idade_de_br(br)
    if i is None:
        return None
    return 'L' if i == 0 else str(i) if str(i) in COR_FAIXA else None


class Painel:
    def __init__(self):
        self.janela = None
        self.controles = []
        self.tentou = False  # já tentou nesta abertura da tela de resumo

    @property
    def aberto(self):
        return bool(self.controles)

    def abrir(self, dados):
        """dados: dict com br, guia e imdb. Desenha o painel no canto superior direito da tela de resumo."""
        self.fechar()
        janela = xbmcgui.Window(JANELA_RESUMO)
        k = (janela.getWidth() or 1920) / 1920.0  # a tela de resumo pode estar em 1080 ou em 720: tudo é proporcional

        def R(v):
            return int(round(v * k))

        branco = os.path.join(xbmcaddon.Addon('service.controle.improprios').getAddonInfo('path'), 'resources', 'media', 'white.png')
        br, guia = dados.get('br'), dados.get('guia')
        faixa = faixa_normalizada(br)
        tem_guia = isinstance(guia, dict) and any(guia.get(c['key']) is not None for c in av.CATEGORIAS)
        nao_identificou = not dados.get('imdb')
        PX, PY, PW = 1340, 70, 540  # mais largo que antes: cabe "Moderado" sem cortar (a borda direita continua em 1880)
        linhas = len(av.CATEGORIAS) if tem_guia else 0
        PH = 222 + linhas * 58 + 50 if (faixa or tem_guia) else (330 if nao_identificou else 190)

        cs = []
        img = lambda x, y, w, h, cor: cs.append(xbmcgui.ControlImage(R(x), R(y), R(w), R(h), branco, colorDiffuse=cor))
        rot = lambda x, y, w, h, txt, cor, alinha=0: cs.append(xbmcgui.ControlLabel(R(x), R(y), R(w), R(h), txt, font='font13', textColor=cor, alignment=alinha))

        img(PX, PY, PW, PH, COR_FUNDO)
        img(PX, PY, PW, 6, '0xFFE50914')
        rot(PX + 30, PY + 22, PW - 60, 40, 'GUIA DE IMPRÓPRIOS', '0xFFFFFFFF')
        if not faixa and not tem_guia:
            caixa = xbmcgui.ControlTextBox(R(PX + 30), R(PY + 80), R(PW - 60), R(90), font='font13', textColor=COR_TEXTO)
            cs.append(caixa)
            if nao_identificou:
                aviso = xbmcgui.ControlTextBox(R(PX + 30), R(PY + 190), R(PW - 60), R(120), font='font13', textColor=COR_CINZA)
                cs.append(aviso)
                self._textos = [(caixa, 'Não consegui identificar este título. Coloque a chave do TMDB nas configurações do addon.'),
                                (aviso, 'O Kodi informou: %s' % dados.get('lido', '?'))]
            else:
                self._textos = [(caixa, 'Sem informações de classificação para este título.')]
        else:
            self._textos = []
            if faixa:
                img(PX + 27, PY + 77, 114, 114, '0x55FFFFFF')
                img(PX + 30, PY + 80, 108, 108, COR_FAIXA[faixa])
                rot(PX + 30, PY + 80, 108, 108, faixa, '0xFFFFFFFF', ALINHA_CENTRO)
                caixa = xbmcgui.ControlTextBox(R(PX + 160), R(PY + 84), R(PW - 190), R(110), font='font13', textColor=COR_TEXTO)
                cs.append(caixa)
                self._textos.append((caixa, TEXTO_FAIXA[faixa]))
            y0 = PY + 222
            for n, c in enumerate(av.CATEGORIAS if tem_guia else []):
                y = y0 + n * 58
                nivel = guia.get(c['key'])
                rot(PX + 30, y, 150, 40, av.CURTOS[c['key']], COR_TEXTO)
                for s in range(3):  # três segmentos: verde, amarelo, vermelho
                    cor = COR_NENHUM if nivel == 0 else (COR_SEGMENTO[s] if nivel is not None and s < nivel else COR_VAZIO)
                    img(PX + 190 + s * 50, y + 13, 44, 14, cor)
                rot(PX + 348, y, 162, 40, av.NIVEIS[nivel] if nivel is not None else '—', cor_do_nivel(nivel))
            if dados.get('imdb'):
                rot(PX + 30, y0 + linhas * 58 + 6, PW - 60, 30, 'IMDb %s' % dados['imdb'], COR_CINZA)
        janela.addControls(cs)
        for caixa, txt in self._textos:
            caixa.setText(txt)
        self.janela, self.controles = janela, cs

    def fechar(self):
        if self.janela is not None and self.controles:
            try:
                self.janela.removeControls(self.controles)
            except Exception:
                pass  # a janela já foi descarregada pelo Kodi: nada a remover
        self.janela, self.controles = None, []
