# -*- coding: utf-8 -*-
"""Entrada do addon: abre as configurações."""
import xbmc

ADDON_ID = 'service.controle.improprios'

# pede ao Kodi para abrir as configurações do addon (o mesmo comando do botão "Configurar")
xbmc.executebuiltin('Addon.OpenSettings(%s)' % ADDON_ID)
