# -*- coding: utf-8 -*-
"""Menu de contexto "Guia de Impróprios": mostra a classificação e o nível de cada categoria do item selecionado,
antes de dar play. Também diz se o título seria liberado ou bloqueado com os limites deste perfil."""
import sys

import xbmc
import xbmcgui

from resources.lib.util import guia_do_item, limpar, ler_config, rpc


def item_do_listitem(li):
    """Monta o mesmo formato de item que o serviço usa, a partir do item selecionado na lista."""
    tag = li.getVideoInfoTag()

    def pegar(nome, padrao=''):
        try:
            v = getattr(tag, nome)()
            return v if v not in (None,) else padrao
        except Exception:
            return padrao

    tipo = pegar('getMediaType')
    item = {'type': tipo, 'title': limpar(pegar('getTitle') or li.getLabel()), 'year': pegar('getYear', 0),
            'imdbnumber': pegar('getIMDBNumber'), 'showtitle': limpar(pegar('getTVShowTitle')),
            'season': pegar('getSeason', -1), 'episode': pegar('getEpisode', -1), 'uniqueid': {}}
    for k in ('imdb', 'tmdb'):
        try:
            v = tag.getUniqueID(k)
            if v:
                item['uniqueid'][k] = v
        except Exception:
            pass
    try:
        dbid = int(pegar('getDbId', -1) or -1)
    except (TypeError, ValueError):
        dbid = -1
    if dbid > 0:  # item da biblioteca: descobre a série para episódios e temporadas
        if tipo == 'tvshow':
            item['tvshowid'] = dbid
            item['showtitle'] = item['showtitle'] or item['title']
        elif tipo == 'episode':
            r = rpc('VideoLibrary.GetEpisodeDetails', {'episodeid': dbid, 'properties': ['tvshowid']}).get('episodedetails') or {}
            item['tvshowid'] = r.get('tvshowid', -1)
        elif tipo == 'season':
            r = rpc('VideoLibrary.GetSeasonDetails', {'seasonid': dbid, 'properties': ['tvshowid']}).get('seasondetails') or {}
            item['tvshowid'] = r.get('tvshowid', -1)
    return item


def main(li=None):
    li = li or getattr(sys, 'listitem', None)
    dlg = xbmcgui.Dialog()
    if li is None:
        return dlg.ok('Guia de Impróprios', 'Não consegui ler o item selecionado.')
    item = item_do_listitem(li)
    cfg = ler_config()
    xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
    try:
        titulo, texto = guia_do_item(item, cfg)
    finally:
        xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
    dlg.textviewer('Guia de Impróprios — %s' % titulo, texto)


if __name__ == '__main__':
    main()
